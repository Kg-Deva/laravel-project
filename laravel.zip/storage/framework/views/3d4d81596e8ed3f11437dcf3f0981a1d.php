<ul class="sidebar-nav" id="sidebar-nav">

    <li class="nav-item">
        <a class="nav-link " href="/data-buku">
            <i class="bi bi-journal-album"></i>
            <span>Data Buku</span>
        </a>
    </li><!-- End Data Buku Nav -->

    <li class="nav-item">
        <a class="nav-link " href="/data-anggota">
            <i class="bi bi-person-lines-fill"></i>
            <span>Data Anggota</span>
        </a>
    </li><!-- End Data Anggota Nav -->

    <li class="nav-item">
        <a class="nav-link " href="/data-pinjam">
            <i class="bi bi-kanban-fill"></i>
            <span>Transaksi Pinjam</span>
        </a>
    </li><!-- End Transaksi Pinjam Nav -->

    <li class="nav-item">
        <a class="nav-link " href="/logout">
            <i class="bi bi-box-arrow-left"></i>
            <span>Logout</span>
        </a>
    </li><!-- End Logout Nav -->
</ul>
<?php /**PATH D:\project\laravel-project\resources\views/sidebar.blade.php ENDPATH**/ ?>